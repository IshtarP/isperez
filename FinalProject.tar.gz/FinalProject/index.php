

<!DOCTYPE html>
<html>
    <head>
        <title>Final Project 336 </title>
        <meta charser="utf=8"/>
        <meta name="viewport" content="width=device-width, initial-scale">
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <style>
            @import url(css/styles.css);
        </style>
    </head>
    <body>
        <!--<h1>The Car Shop</h1>-->
        
        <!-- Might make a box to keep the form together-->
        <div class='container'>
            <div class='text-center'>
                
                <!-- Bootstrap Navagation Bar -->
                <nav class='navbar navbar-inverse - navbar-fixed-middle'>
                <div class='container-fluid'>
                    <div class='navbar-header'>
                        <a class='navbar-brand' href='#'></a>
                    </div>
                    <ul class='nav navbar-nav'>
                        <li><a href='home.php'>Home</a></li>
                        <li><a href='scart.php'>
                        <span class='glyphicon glyphicon-shopping-cart' aria-hidden='true'>
                           <!-- </span>Cart: <?php displayCartCount(); ?> </a></li>-->
                    </ul>
                </div>
            </nav>
            <br /> <br /> <br />
           
            </div>
        </div>

    </body>
</html>