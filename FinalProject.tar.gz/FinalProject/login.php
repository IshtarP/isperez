<?php
    
    session_start(); 
    
    include '../../dbConnection.php';
    
    $conn = getDatabaseConnection()
?>